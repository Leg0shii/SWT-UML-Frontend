import java.rmi.*;
import java.rmi.server.*;

public interface RMIServerInterface extends Remote {
    //Signaturen der Serverfunktionen mit RemoteException:
    public long login(int clientID, String username, String pwdHash) throws RemoteException;
}
