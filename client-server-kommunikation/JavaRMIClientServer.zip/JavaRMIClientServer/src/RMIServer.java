import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.*;

public class RMIServer extends UnicastRemoteObject implements RMIServerInterface{

    public RMIServer() throws RemoteException{}

   //Funktionen des Servers:
   public long login(int clientID, String username, String pwdHash){
       // TODO JAKOB

       //Test:
       long testval = 424242;
       System.out.println("Login ausgeführt");
       return testval;
   }
}
