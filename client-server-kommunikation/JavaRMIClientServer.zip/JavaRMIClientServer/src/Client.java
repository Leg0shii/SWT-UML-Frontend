import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;

public class Client {
    int clientID;

    public Client() {
        //Constructor
        this.clientID = this.generateClientID();
    }

    private int generateClientID(){
        /*
        * Funktion soll ClientID erstellen
        * ggf Anfrage an Server auf offene IDs
        * aus Testzwecken 42
         */
        return 42;
    }

    private String hashFunction(String password){
        return password;
    }

    public int getClientID() {
        return clientID;
    }

    public static void main(String[] args){
        //System.setSecurityManager(new RMISecurityManager());
        Client client = new Client();
        String registryName = "RMIServer"; //Name in Registry
        try {
            RMIServerInterface server = (RMIServerInterface)Naming.lookup(registryName);
            long sessionKey = server.login(client.getClientID(), "admin", "password");
            System.out.println("SessionKey: " + sessionKey);

        } catch (NotBoundException | MalformedURLException | RemoteException e) {
            e.printStackTrace();
            e.getCause();
        }
    }
}
