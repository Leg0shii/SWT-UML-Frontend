import java.net.MalformedURLException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.Naming;

public class Server {
    public Server() {
    }

    public static void main(String[] args){

        //System.setSecurityManager(new RMISecurityManager());
        try {

            RMIServer server = new RMIServer(); //Server bereitstellen
            Naming.rebind("RMIServer", server); //Servername in Registry schreiben und auf Objekt binden

        } catch (RemoteException | MalformedURLException e) {
            e.printStackTrace();
            System.out.println("ERROR");
        }
    }
}
